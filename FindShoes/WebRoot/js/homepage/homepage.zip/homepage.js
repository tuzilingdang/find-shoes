// JavaScript Document
/*var flag;*/


     $(document).ready(function(){ }); 
			
            var href ="" ;
				
			function changeDisplay(s){
				var helloDivObj = $("#div-folder");   
			    var buttonObj1 = $("#btnDisplay1");   
			    var buttonObj2 =  $("#btnDisplay2");
				var val = s;
				if(val=="more"){
					/*<!--helloDivObj.style.display='block';-->*/
					helloDivObj.show();
					/*<!--document.getElementById("#helloDiv").style.visibility="visible";-->	*/	
					 buttonObj1.hide();  
					/* document.getElementById("#btnDisplay1").style.display="none";*/
					/*buttonObj1.attr(display,none);*/
					 $("#div-folder").append("<input id='btnDisplay2' class='btnDisplay' type='button' value='收起' onclick='changeDisplay()'/> ");                 
					 val = buttonObj1.attr("value");				  
					  buttonObj2.show();}
					
				else{
					helloDivObj.hide();
					buttonObj1.show();     
					$("#btnDisplay2").remove("#btnDisplay2 ");	
					val = buttonObj2.attr("value");
					 }
					
				}
			
			function findFlag(thisURL){
				if(thisURL.indexOf("*") > 0 )  
					{  
						return false;  
					}
				else 
					return true;
				}
			
			
/*************************************************弹窗部分***************************************************/			
        	function btnPop_onclick(str) {	
			    var thisURL = document.URL;    
 				window.flag = findFlag(thisURL);	
				var cover = "<div id='Cover' onclick='btnClose_onclick()'></div>";
				$("body").append(cover);
				var pop = "<div id='Pop'></div>";
				var popContent = "<div class='popContent'></div>";
			/*	var buttonGroup = "<fieldset data-role='controlgroup' class='pop-buttonGroup'></fieldset>";*/
				
				var grid_b1 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b1' data-theme='f' ></div>"; /*品牌弹窗函数*/
				var grid_b2 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b2' data-theme='f' ></div>"; /*季节弹窗函数*/
				var grid_b3 = "<div  data-role='ui-grid-solo'  id='ui-grid-b3' data-theme='f' style='height:23.5em' ></div>"; /*价格弹窗函数*/
				var grid_b4 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b4' data-theme='f' ></div>"; /*选购热点弹窗函数*/
				var grid_b5 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b5' data-theme='f' ></div>"; /*跟高弹窗函数*/
				var grid_b6 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b6' data-theme='f' ></div>"; /*流行元素弹窗函数*/
				var grid_b7 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b7' data-theme='f' ></div>"; /*场合弹窗函数*/
				var grid_b8 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b8' data-theme='f' ></div>"; /*场合弹窗函数*/
				var grid_b9 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b9' data-theme='f' ></div>"; /*鞋头弹窗函数*/
				var grid_b10 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b10' data-theme='f' ></div>"; /*跟型弹窗函数*/
				var grid_b11 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b11' data-theme='f' ></div>"; /*皮质特征弹窗函数*/
				var grid_b12 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b12' data-theme='f' ></div>"; /*鞋底材质弹窗函数*/
				var grid_b13 = "<div  data-role='ui-grid-b' class='ui-grid-b' id='ui-grid-b13' data-theme='f' ></div>"; /*沿口高度弹窗函数*/
				
				
				var form_price = "<form method='get' action='xxx.asp' id='form_price'></form>";
				
				switch(str){
					case "brand":
						$("body").append(pop);
						pop_brands(pop,grid_b1,form_price,"brand"); break;
					case "season":
						$("body").append(pop);
						pop_season(pop,grid_b2,form_price,"season"); break;
					case "price":
						$("body").append(pop); /*passval_price("price");*/
						pop_price(pop,grid_b3,form_price,"price"); break;
					case "hotwords":
						$("body").append(pop);
						pop_hotwords(pop,grid_b4,form_price,"hotwords");break;
					case "height":
						$("body").append(pop);
						pop_height(pop,grid_b5,form_price,"height");break;
					case "pop":
						$("body").append(pop);
						pop_pop(pop,grid_b6,form_price,"pop");break;    
					case "occasion":
						$("body").append(pop);
						pop_occasion(pop,grid_b7,form_price,"occasion");break;
					case "style":
						$("body").append(pop);
						pop_style(pop,grid_b8,form_price,"style");break;
					case "toecap":
						$("body").append(pop);
						pop_toecap(pop,grid_b9,form_price,"toecap");break;
					case "heeltype":
						$("body").append(pop);
						pop_heeltype(pop,grid_b10,form_price,"heeltype");break;
					case "leather_f":
						$("body").append(pop);
						pop_leather_f(pop,grid_b11,form_price,"leather_f");break;
					case "bottom_material":
						$("body").append(pop);
						pop_bottom_material(pop,grid_b12,form_price,"bottom_material");break;
					case "upper_h":
						$("body").append(pop);
						pop_upper_h(pop,grid_b13,form_price,"upper_h");break;
					default:
						break;
					}
				}
					
				/*品牌弹窗函数*/
				function pop_brands(pop,grid_b1,form_price,cdit_name){
					if (  window.flag == true )
						window.href = "./classify-find.jsp?";
					else
						window.href = document.URL;	
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>品牌</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b1+"<input class='btn-clear' type='button' value='清除' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"brand\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b1").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='百丽' id='chk-price-1'  /> <label for='chk-price-1'><h4>百丽</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='达芙妮' id='chk-price-2'  /> <label for='chk-price-2'><h4>达芙妮</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='他她' id='chk-price-3'  /> <label for='chk-price-3'><h4>他她</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='千百度' id='chk-price-4'  /> <label for='chk-price-4'><h4>千百度</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='红蜻蜓' id='chk-price-5'  /> <label for='chk-price-5'><h4>红蜻蜓</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='星期六' id='chk-price-6'  /> <label for='chk-price-6'><h4>星期六</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='天美意' id='chk-price-7'  /> <label for='chk-price-7'><h4>天美意</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='接吻猫' id='chk-price-8'  /> <label for='chk-price-8'><h4>接吻猫</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='思加图' id='chk-price-9'  /> <label for='chk-price-9'><h4>思加图</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='卓诗尼' id='chk-price-10'  /> <label for='chk-price-10'><h4>卓诗尼</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='哈森' id='chk-price-11'  /> <label for='chk-price-11'><h4>哈森</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='Gucci' id='chk-price-12'  /> <label for='chk-price-12'><h4>Gucci</h4></label></div>"
					);
			  	} 	
								
				
				/*季节弹窗函数*/
				function pop_season(pop,grid_b2,form_price,cdit_name){
					/*document.write(getValue()); 	*/
	                if ( window.flag == true ){
						window.href = "./classify-find.jsp?";
						}
					else
						window.href = document.URL;	
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>季节</h2></div>"
						  + form_price
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b2+"<input class='btn-clear' type='button' value='清除' onclick='clear_val()'/>"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"season\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b2").append(
						"<div data-role='ui-block-a' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='春秋季' id='chk-price-1' data-mini='true'/> <label for='chk-price-1'><h4>春秋季</h4></label></div>"
						+"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck'  value='夏季' id='chk-price-2' data-mini='true'/> <label for='chk-price-2'><h4>夏季</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-c' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='冬季' id ='chk-price-3' data-mini='true'/> <label for='chk-price-3'><h4>冬季</h4></label></div>"	
					);
			  	} 	
				
				/*价格弹窗函数*/
				function pop_price(pop,grid_b3,form_price,cdit_name){
/*					alert(window.href);*/
					if ( window.flag == true){
						window.href = "./classify-find.jsp?";
						}
					else
						window.href = document.URL;	
						href = window.href;
					/*document.write(flag);*/
						$("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						+ "<div class=' popMain'>"
						+"<div class ='pop_title'><h2 class='pop_title-h2'>价格</h2></div>"
						+ form_price
						+ "<div style='margin-top:22px;'>"						
					 );

					$("#form_price").append(grid_b3+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						+ "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"price\")'/>" 	);  
					 
					$("#ui-grid-b3").append(
					  "<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='<100' id='chk-price-1' data-mini='true'/> <label for='chk-price-1'><h4><100</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='100-199' id='chk-price-2' data-mini='true'/> <label for='chk-price-2'><h4>100-199</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='200-299' id='chk-price-3' data-mini='true'/> <label for='chk-price-3'><h4>200-299</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='300-399' id='chk-price-4' data-mini='true'/> <label for='chk-price-4'><h4>300-399</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='400-599' id='chk-price-5' data-mini='true'/> <label for='chk-price-5'><h4>400-599</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='600-999' id='chk-price-6' data-mini='true'/> <label for='chk-price-6'><h4>600-999</h4></label></div>"
					  +"<div data-role='ui-block-a' class='ui-block-a-3'><input type='checkbox' data-theme='c' name='ck' value='>1000' id='chk-price-7' data-mini='true'/> <label for='chk-price-7'><h4>>1000</h4></label></div>"
				  );
							}
					
				/*选购热点弹窗函数*/
				function pop_hotwords(pop,grid_b4,form_price,cdit_name){
					
					if ( window.flag == true)
						window.href = "./classify-find.jsp?";
					else
						window.href = document.URL;	
					
					$("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						+ "<div class=' popMain'>"
						+"<div class ='pop_title'><h2 class='pop_title-h2'>选购热点</h2></div>"
						+ form_price/*grid_b4*/
						+ "<div style='margin-top:22px;'>"			
					 );
					 
					$("#form_price").append (grid_b4+ "<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						+ "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"hotwords\")' />");
						
					$("#ui-grid-b4").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='摇摇鞋' id='chk-price-1'  /> <label for='chk-price-1'><h4>摇摇鞋</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='松糕鞋' id='chk-price-2'  /> <label for='chk-price-2'><h4>松糕鞋</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='帆布鞋' id='chk-price-3'  /> <label for='chk-price-3'><h4>帆布鞋</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='板鞋' id='chk-price-4'  /> <label for='chk-price-4'><h4>板鞋</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='中筒靴' id='chk-price-5'  /> <label for='chk-price-5'><h4>中筒靴</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='内增高' id='chk-price-6'  /> <label for='chk-price-6'><h4>内增高</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='舞蹈鞋' id='chk-price-7'  /> <label for='chk-price-7'><h4>舞蹈鞋</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='高筒靴' id='chk-price-8'  /> <label for='chk-price-8'><h4>高筒靴</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='厚底鞋' id='chk-price-9'  /> <label for='chk-price-9'><h4>厚底鞋</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='低筒靴' id='chk-price-10'  /> <label for='chk-price-10'><h4>低筒靴</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='皮毛一体' id='chk-price-11'  /> <label for='chk-price-11'><h4>皮毛一体</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='坡跟鞋' id='chk-price-12'  /> <label for='chk-price-12'><h4>坡跟鞋</h4></label></div>"
				  );

			  	} 
			
        	function pop_height(pop,grid_b5,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	

					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>跟高</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b5+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"height\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b5").append(
						"<div data-role='ui-block-a' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='平跟' id='chk-price-1' data-mini='true'/> <label for='chk-price-1'><h4>平跟</h4></label></div>"
						+"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck'  value='低跟' id='chk-price-2' data-mini='true'/> <label for='chk-price-2'><h4>低跟</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-c' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='中跟' id ='chk-price-3' data-mini='true'/> <label for='chk-price-3'><h4>中跟</h4></label></div>"	
						+"<div data-role='ui-block-c' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='高跟' id ='chk-price-4' data-mini='true'/> <label for='chk-price-4'><h4>高跟</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='超高跟' id ='chk-price-5' data-mini='true'/> <label for='chk-price-5'><h4>超高跟</h4></label></div>"
					);
			  	} 	
				
			    function pop_pop(pop,grid_b6,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	
					  /*document.write(window.href);*/
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>流行元素</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b6+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"pop\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b6").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='蝴蝶结' id='chk-price-1'  /> <label for='chk-price-1'><h4>蝴蝶结</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='拼接撞色' id='chk-price-2'  /> <label for='chk-price-2'><h4>拼接撞色</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='豹纹' id='chk-price-3'  /> <label for='chk-price-3'><h4>豹纹</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='水钻' id='chk-price-4'  /> <label for='chk-price-4'><h4>水钻</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='糖果色' id='chk-price-5'  /> <label for='chk-price-5'><h4>糖果色</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='波点' id='chk-price-6'  /> <label for='chk-price-6'><h4>波点</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='流苏' id='chk-price-7'  /> <label for='chk-price-7'><h4>流苏</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='格子纹' id='chk-price-8'  /> <label for='chk-price-8'><h4>格子纹</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='亮片' id='chk-price-8'  /> <label for='chk-price-9'><h4>亮片</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='串珠' id='chk-price-10'  /> <label for='chk-price-10'><h4>串珠</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='金属装饰' id='chk-price-11'  /> <label for='chk-price-11'><h4>金属装饰</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='交叉绑带' id='chk-price-12'  /> <label for='chk-price-12'><h4>交叉绑带</h4></label></div>"
					);
			  	} 	
			
			function pop_occasion(pop,grid_b7,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?"+"$";
					else
						window.href = document.URL+"$";	
					  /*document.write(window.href);*/
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>场合</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b7+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"occasion\")'/>"	); 
					  $("#ui-grid-b7").append(
					    "<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='通勤' id='chk-price-1'  /> <label for='chk-price-1'><h4>通勤</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='约会' id='chk-price-2'  /> <label for='chk-price-2'><h4>约会</h4></label></div>"		          
					  + "<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='聚会' id='chk-price-3'  /> <label for='chk-price-3'><h4>聚会</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='逛街' id='chk-price-4'  /> <label for='chk-price-4'><h4>逛街</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='休闲' id='chk-price-5'  /> <label for='chk-price-5'><h4>休闲</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='结婚' id='chk-price-6'  /> <label for='chk-price-6'><h4>结婚</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='沙滩' id='chk-price-7'  /> <label for='chk-price-7'><h4>沙滩</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='旅行' id='chk-price-8'  /> <label for='chk-price-8'><h4>旅行</h4></label></div>"
					);
			  	} 	
			
			 function pop_style(pop,grid_b8,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	
					  /*document.write(window.href);*/
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>风格</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b8+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"style\")'/>"	);
					  $("#ui-grid-b8").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='韩系' id='chk-price-1'  /> <label for='chk-price-1'><h4>韩系</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='日系' id='chk-price-2'  /> <label for='chk-price-2'><h4>日系</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='罗马' id='chk-price-3'  /> <label for='chk-price-3'><h4>罗马</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='欧美' id='chk-price-4'  /> <label for='chk-price-4'><h4>欧美</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='森女' id='chk-price-5'  /> <label for='chk-price-5'><h4>森女</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='田园' id='chk-price-6'  /> <label for='chk-price-6'><h4>田园</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='中国风' id='chk-price-7'  /> <label for='chk-price-7'><h4>中国风</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='通勤' id='chk-price-8'  /> <label for='chk-price-8'><h4>通勤</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='波西米亚' id='chk-price-9'  /> <label for='chk-price-9'><h4>波西米亚</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='休闲' id='chk-price-10'  /> <label for='chk-price-10'><h4>休闲</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='街头' id='chk-price-11'  /> <label for='chk-price-11'><h4>街头</h4></label></div>"	
					);
			  	} 	
				
		       function pop_toecap(pop,grid_b9,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	
					  /*document.write(window.href);*/
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>鞋头</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b9+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"toecap\")'/>"	);	 
					  $("#ui-grid-b9").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='圆头' id='chk-price-1'  /> <label for='chk-price-1'><h4>圆头</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='尖头' id='chk-price-2'  /> <label for='chk-price-2'><h4>尖头</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='方头' id='chk-price-3'  /> <label for='chk-price-3'><h4>方头</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='夹趾' id='chk-price-4'  /> <label for='chk-price-4'><h4>夹趾</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='露趾' id='chk-price-5'  /> <label for='chk-price-5'><h4>露趾</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='鱼嘴' id='chk-price-6'  /> <label for='chk-price-6'><h4>鱼嘴</h4></label></div>"					 
					);
			  	} 	
				
				/*选购热点弹窗函数*/
				function pop_heeltype(pop,grid_b10,form_price,cdit_name){
					
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	
					
					$("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						+ "<div class=' popMain'>"
						+"<div class ='pop_title'><h2 class='pop_title-h2'>跟型</h2></div>"
						+ form_price/*grid_b4*/
						+ "<div style='margin-top:22px;'>"
						
					 );
					 
					$("#form_price").append (grid_b10+ "<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						+ "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"heeltype\")' />");
						
					$("#ui-grid-b10").append(
					"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='细跟' id='chk-price-2'  /> <label for='chk-price-2'><h4>细跟</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='酒杯跟' id='chk-price-3'  /> <label for='chk-price-3'><h4>酒杯跟</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='内增高' id='chk-price-4'  /> <label for='chk-price-4'><h4>内增高</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='镂空跟' id='chk-price-5'  /> <label for='chk-price-5'><h4>镂空跟</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='粗跟' id='chk-price-6'  /> <label for='chk-price-6'><h4>粗跟</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='方根' id='chk-price-7'  /> <label for='chk-price-7'><h4>方根</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='锥形跟' id='chk-price-8'  /> <label for='chk-price-8'><h4>锥形跟</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='异形跟' id='chk-price-9'  /> <label for='chk-price-9'><h4>异形跟</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='平跟' id='chk-price-10'  /> <label for='chk-price-10'><h4>平跟</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='坡跟' id='chk-price-11'  /> <label for='chk-price-11'><h4>坡跟</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='马蹄跟' id='chk-price-12'  /> <label for='chk-price-12'><h4>马蹄跟</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='松糕底' id='chk-price-12'  /> <label for='chk-price-12'><h4>松糕底</h4></label></div>"
				  );
			  	} 	
				
				
			  function pop_leather_f(pop,grid_b11,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	

					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>皮质特征</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b11+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"leather_f\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b11").append(
						"<div data-role='ui-block-a' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='软面皮' id='chk-price-1' data-mini='true'/> <label for='chk-price-1'><h4>软面皮</h4></label></div>"
						+"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck'  value='磨砂皮' id='chk-price-2' data-mini='true'/> <label for='chk-price-2'><h4>磨砂皮</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-c' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='漆皮' id ='chk-price-3' data-mini='true'/> <label for='chk-price-3'><h4>漆皮</h4></label></div>"	
						+"<div data-role='ui-block-c' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='压花皮' id ='chk-price-4' data-mini='true'/> <label for='chk-price-4'><h4>压花皮</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='印花皮' id ='chk-price-5' data-mini='true'/> <label for='chk-price-5'><h4>印花皮</h4></label></div>"
					);
			  	} 					
			
			
			 function pop_bottom_material(pop,grid_b12,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	
					  /*document.write(window.href);*/
					  
					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>鞋底材质</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b12+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"bottom_material\")'/>"	);
					  $("#ui-grid-b12").append(
"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='橡胶底' id='chk-price-1'  /> <label for='chk-price-1'><h4>橡胶底</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='塑胶底' id='chk-price-2'  /> <label for='chk-price-2'><h4>塑胶底</h4></label></div>"		          
					  +"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='真皮底' id='chk-price-3'  /> <label for='chk-price-3'><h4>真皮底</h4></label></div>"	
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='千层底' id='chk-price-4'  /> <label for='chk-price-4'><h4>千层底</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='牛筋底' id='chk-price-5'  /> <label for='chk-price-5'><h4>牛筋底</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='复合底' id='chk-price-6'  /> <label for='chk-price-6'><h4>复合底</h4></label></div>"					 
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='泡沫底' id='chk-price-7'  /> <label for='chk-price-7'><h4>泡沫底</h4></label></div>"
					  +	"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-b-2'><input type='checkbox' data-theme='c' name='ck' value='木底' id='chk-price-8'  /> <label for='chk-price-8'><h4>木底</h4></label></div>"
					);
			  	} 		
				
				function pop_upper_h(pop,grid_b13,form_price,cdit_name){
					if ( window.flag == true)
						window.href = "./classify-find-unfold.jsp?";
					else
						window.href = document.URL;	

					  $("#Pop").append("<div class='btnClose'  onclick='return btnClose_onclick()'>X</div>"
						  + "<div class=' popMain'>"
						  +"<div class ='pop_title'><h2 class='pop_title-h2'>沿口高度</h2></div>"
						  + form_price
					  /*	+ grid_b2*/
						  + "<div style='margin-top:22px;'>"
						  
					   );
					  $("#form_price").append(grid_b13+"<input class='btn-clear' type='button' value='清除'  onclick='clear_val()' />"
						  + "<input class='btn-sure' type='button' value='确定' onclick='passval_price(\"upper_h\")'/>"	); /*onclick='test()'*/
					  $("#ui-grid-b13").append(
						"<div data-role='ui-block-a' class='ui-block-a' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='浅口' id='chk-price-1' data-mini='true'/> <label for='chk-price-1'><h4>浅口</h4></label></div>"
						+"<div data-role='ui-block-b' class='ui-block-b' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck'  value='中口' id='chk-price-2' data-mini='true'/> <label for='chk-price-2'><h4>中口</h4></label></div>"
						+"<div data-role='ui-block-c' class='ui-block-c' id='ui-block-a-2'><input type='checkbox' data-theme='c' name='ck' value='深口' id ='chk-price-3' data-mini='true'/> <label for='chk-price-3'><h4>深口</h4></label></div>"	

					);
			  	} 
			
		function btnClose_onclick() {
				$("#Cover").remove();
				$("#Pop").remove();
			}
 
        function clear_val(){
			$("[name='ck']").removeAttr("checked");//取消全选    		
			}
 
 
 /*************************************************solo显示部分/checkbox选择值回传***************************************************/
		function passval_price(cdit_name){/*a,b,c,d,e,f,g*/
/*			window.href = window.href.split('$')[0]; */  
			var param ="";   
            if(document.getElementById("chk-price-1")!= null && document.getElementById("chk-price-1").checked){
				param+=document.getElementById("chk-price-1").value+",";  
				}     				         
            if(document.getElementById("chk-price-2")!= null && document.getElementById("chk-price-2").checked)
                param+=document.getElementById("chk-price-2").value+",";
			if(document.getElementById("chk-price-3")!= null && document.getElementById("chk-price-3").checked)
                param+=document.getElementById("chk-price-3").value+",";
			if(document.getElementById("chk-price-4")!= null && document.getElementById("chk-price-4").checked)				 
				  	param+=document.getElementById("chk-price-4").value+",";               
		    if(document.getElementById("chk-price-5")!= null && document.getElementById("chk-price-5").checked)
                param+=document.getElementById("chk-price-5").value+",";
			if(document.getElementById("chk-price-6")!= null && document.getElementById("chk-price-6").checked)
                param+=document.getElementById("chk-price-6").value+",";
			if(document.getElementById("chk-price-7")!= null && document.getElementById("chk-price-7").checked)
                param+=document.getElementById("chk-price-7").value+",";
			if(document.getElementById("chk-price-8")!= null && document.getElementById("chk-price-8").checked)
                param+=document.getElementById("chk-price-8").value+",";
			if(document.getElementById("chk-price-9")!= null && document.getElementById("chk-price-9").checked)
                param+=document.getElementById("chk-price-9").value+",";
			if(document.getElementById("chk-price-10")!= null && document.getElementById("chk-price-10").checked)
                param+=document.getElementById("chk-price-10").value+",";
			if(document.getElementById("chk-price-11")!= null && document.getElementById("chk-price-11").checked)
                param+=document.getElementById("chk-price-11").value+",";
			if(document.getElementById("chk-price-12")!= null && document.getElementById("chk-price-12").checked)
                param+=document.getElementById("chk-price-12").value+",";
					
            param = param.substring(0,param.length-1);
			/*var rr = document.getElementById('chk-price-4');
			document.write(rr);*/
			/*document.location.href="xxx.jsp?param="+param;*/

		/*	pre_href = window.href;*/
		    if(window.flag == true)
				window.href = window.href+"*"+cdit_name+"="+param+"&";
			else
			    window.href = window.href+cdit_name+"="+param+"&";
            /*document.write(window.href );*/
			document.location.href = window.href;
			/*document.write(param);*/
			/*$("#ui-block-price").append("<label>param</label>");*/
			/*return href;*/
		}
		
		function test(){
			document.write(window.href);
		}